# scrape-grund
VN scraper Grund und Boden

# usage
conda activate selenium
python scrape_fk.py
